"""Miscreant: A misuse-resistant symmetric encryption library"""
