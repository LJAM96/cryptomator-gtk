"""Message Authentication Codes"""
